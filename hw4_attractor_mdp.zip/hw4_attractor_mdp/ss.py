countries = ["usa", "india", "pakistan", "israel"]

for i in range(len(countries)):
    country = countries[i]
    print(country)
    print(country[0])
    if country[0] == "i":
        countries[i] = chr(ord(countries[i][0]) - 32) + countries[i][1:]  + " is great"
print(countries)

##output
#
# ["usa", "india is great", ..]
