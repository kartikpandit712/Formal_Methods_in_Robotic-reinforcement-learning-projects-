from Gridworld import *
from AttractorSolver import *
import numpy as np

height = 10  #GridWorld height
width = 10  #GridWorld width
Wall = [(3, 7), (3, 8), (4, 7), (6, 7), (7, 6), (7, 7), (8, 6)]   #Bouncing walls in the Map
Sink = [(0, 0), (7, 0)]   #Consider it as Cheese & Trap position
init = np.zeros(height * width - len(Wall))
gridwsto = get_MDP(height, width, Wall, Sink, init)

# Choose your own set F within the gridworld.
# Let's consider F to be all the states that are neither walls nor sinks.
F = {(i, j) for i in range(height) for j in range(width) if (i, j) not in Wall and (i, j) not in Sink}

# Implement the functions
# Assuming get_attr is an alias for get_attractor or a similar function in AttractorSolver.
Ysets, Xsets, pol = get_attractor(gridwsto, F)

# Here, Ysets will be the collection of sets that form the almost-sure winning region, Xsets will be the attractor sets, 
# and pol will be the policy that ensures winning from the winning region.
