# -*- coding: utf-8 -*-
"""
Created on Thu Jun 29 16:27:12 2023

@author: hma2
"""

import numpy as np
import copy
import random


class GridWorld:
    def __init__(self, height, width, init, Wall, Sink, stoPar, labels = None):
        """
        Fully observable gridworld for labeled Markov decision process.
        :param height: number of rows
        :param width: number of cols.
        :param init: (x,y) coordinate for the initial state
        :param Wall: a set of cells that cannot be traversed.
        :param stoPar: a parameter within [0,1] to define the stochasticity in the agent dynamics. \\
        If the agent moves North, with a proabability 1- 2*stoPar, it moves to the intended cell.
        with probability stoPar, it moves to one of the neighboring cells. If the next cell is a wall cell, it stays in the same cell.
        :param labels: a dictionary that labels for each state, a set of atomic propositions evaluated true.
        """
        self.init = init
        self.Sink = Sink
        self.Wall = Wall
        #Change your stochasticity here
        self.stoPar = stoPar
        self.states = self.getStates(height, width)
        self.removeWall(Wall)         #Walls can not be entered, so remove walls from valid states
        self.actions = self.getActions()
        #Default reward function, you may not need to include it here
        # self.reward = self.reward_Goal_Obstacle(20, -2)
        self.transition = self.getTransition()
        self.ChangeSinkTrans()
        self.labels = labels

        # self.nextSt_list, self.nextPro_list = self.stotrans_list()   #Not needed if you do not consider HMM
    def getLabel(self, state):
        # return the label of a given state.
        return self.labels(state)

    def getStates(self, height, width):
        #Get all possible states
        states = []
        for i in range(height):
            for j in range(width):
                states.append((i, j))
        return states
    
    def getActions(self):
        #5 actions including stay and 4 different directions.
        actions = [(0, 1), (0, -1), (-1, 0), (1, 0), (0, 0)] #right, left down, up, stay
        return actions
    
    def complementaryActions(self, action):
        #Use to find out stochastic transitions, if stay, no stochasticity, if other actions, return possible stochasticity directions.
        if action == (0, 0):
            return []
        elif action[0] == 0:
            return [(1, 0), (-1, 0)]
        else: 
            return [(0, 1), (0, -1)]

        
    
    def getTransition(self):
        #Construcing transition function trans[state][action][next_state] = probability
        stoPar = self.stoPar
        trans = {}
        for st in self.states:
            trans[st] = {}
            for act in self.actions:
                if act == (0, 0):
                    trans[st][act] = {}
                    trans[st][act][st] = 1
                else:
                    trans[st][act] = {}
                    trans[st][act][st] = 0
                    tempst = tuple(np.array(st) + np.array(act))
                    if self.checkinside(tempst):
                        trans[st][act][tempst] = 1 - 2 * stoPar
                    else:
                        trans[st][act][st] += 1- 2 * stoPar
                    for act_ in self.complementaryActions(act):
                        tempst_ = tuple(np.array(st) + np.array(act_))
                        if self.checkinside(tempst_):
                            trans[st][act][tempst_] = stoPar
                        else:
                            trans[st][act][st] += stoPar
        self.check_trans(trans)
        return trans
    
    def check_trans(self, trans):
        #Check if the transitions are constructed correctly
        for st in trans.keys():
            for act in trans[st].keys():
                if abs(sum(trans[st][act].values())-1) > 0.01:
                    print("st is:", st, " act is:", act, " sum is:", sum(self.stotrans[st][act].values()))
                    return False
        print("Transition is correct")
        return True
    
    def checkinside(self, st):
        #If the state is valid or not
        if st in self.states:
            return True
        return False
    
    def removeWall(self, Wall):
        #Walls can not be entered, so remove walls from valid states
        for st in Wall:
            self.states.remove(st)



    def ChangeSinkTrans(self):
        #Sink should all goes to "Sink" states
        for s in self.Sink:
            self.transition[s] = {}
            for act in self.actions:
                self.transition[s][act] = {}
                self.transition[s][act]["Sink"] = 1.0

    def get_reward(self, Reward):
        # Assign reward function to the MDP. Not required for qualitative planning.
        return
    def get_next_supp(self, s,a):
        """

        :param s: state
        :param a: action
        :return: a set of possible next states that can be reached with probability >0.
        """
        X = set([])
        # todo: implement using the transition function of the MDP.

        return X

    def generate_traj(self, pi, T):
            """
            Generate a trajectory of length T given a policy pi.
            
            Parameters:
            - pi: a policy, which is a mapping from state to action.
            - T: length of the trajectory.
            
            Returns:
            - traj: a list representing the trajectory [s0, a0, s1, a1, ... sT].
            """
            # Start from the initial state
            state = self.init
            traj = []
            #print(state)
            for _ in range(T):
                # Given the current state, choose an action based on the policy
                print(type(state))
                action = pi[state]
                # Get the next state based on transition dynamics and chosen action
                next_state = self.sample_next_state(state, action)
                traj.extend([action, next_state])
                # Move to the next state for the next iteration
                state = next_state
            
            return traj

    def sample_next_state(self, state, action):
        """
        Sample the next state given a current state and an action based on the transition model.
        
        Parameters:
        - state: the current state.
        - action: the action taken.
        
        Returns:
        - next_state: a sampled next state.
        """
        next_states = list(self.transition[state][action].keys())
        probs = list(self.transition[state][action].values())
        next_state = random.choices(next_states, weights=probs, k=1)[0]
        return next_state
    
def get_deterTS(height, width, Wall, Sink, init):
    stoPar = 0
    GridWDeter =  GridWorld(height, width, init, Wall, Sink, stoPar)
    return GridWDeter


def get_MDP(height, width, Wall, Sink, init):
    # Todo:
    stoPar = 0.2
    GridWMDP = GridWorld(height, width, init, Wall, Sink, stoPar)
    return GridWMDP

def print_policy(pi):
    """Print the policy in a readable format."""
    for state, action in pi.items():
        print(f"State: {state} -> Action: {action}")

def save_policy_to_file(pi, filename='policy.txt'):
    """Save the policy to a file."""
    with open(filename, 'w') as f:
        for state, action in pi.items():
            f.write(f"State: {state} -> Action: {action}\n")

def print_trajectory(traj):
    """Print the trajectory in a readable format."""
    for i in range(0, len(traj), 2):  # Assuming the format [s0, a0, s1, a1, ...]
        print(f"State: {traj[i]} -> Action: {traj[i+1]}")

def save_trajectory_to_file(traj, filename='trajectory.txt'):
    """Save the trajectory to a file."""
    with open(filename, 'w') as f:
        for i in range(0, len(traj), 2):
            f.write(f"State: {traj[i]} -> Action: {traj[i+1]}\n")


    
def main():
    height = 10 #GridWorld height
    width = 10 #GridWorld width
    Wall = [(3, 7), (3, 8), (4, 7), (6, 7), (7, 6), (7, 7), (8, 6)] #Bouncing␣ walls in the Map
    Sink = [(0, 0), (7, 0)] #Consider it as Cheese & Trap position
    init = init = (height-1, width-1)
    #GridWorld = get_deterTS(height, width, Wall, Sink, init)
    GridWorldInstance = get_MDP(height, width, Wall, Sink, init) # NOTICE THE FUNCTION␣
    ##GENERATES MDP instead of deterministic transition system
    #return GridWorld
    pi = {state: random.choice(GridWorldInstance.actions) for state in GridWorldInstance.states}
    
    # Print and save the policy
    print("Policy:")
    print_policy(pi)
    save_policy_to_file(pi)

    print(pi)
    
     # Generate a trajectory based on the policy
    T = 50  # For example, if you want a trajectory of length 50
    traj = GridWorldInstance.generate_traj(pi, T)

    # Print and save the trajectory
    print("\nTrajectory:")
    print_trajectory(traj)
    save_trajectory_to_file(traj)
    
    return GridWorldInstance
    
    
    
if __name__ == "__main__":
    GridWorld = main()
    print("Done the construction of a gridworld")