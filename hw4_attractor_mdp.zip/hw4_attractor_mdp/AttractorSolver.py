from Gridworld import *
import copy

def get_APre(gridW, X, Y):
    APre = set()
    for state in gridW.states:
        for act in gridW.actions:
            next_states = gridW.transition[state][act]
            if any([next_state in X for next_state in next_states.keys()]) and all([next_state in Y for next_state in next_states.keys()]):
                APre.add(state)
    return APre

def get_attr_deter(gridwdeter, F):
    X_new = set(copy.deepcopy(F))
    pol = {}
    while True:
        X_prev = copy.deepcopy(X_new)
        for state in gridwdeter.states:
            for act in gridwdeter.actions:
                next_state = gridwdeter.transition[state][act]
                if next_state in X_prev:
                    X_new.add(state)
                    pol[state] = act
        if X_prev == X_new:
            break
    return X_new, pol

def get_attr_uc(gridwdeter, F):
    X_new = set(copy.deepcopy(F))
    pol = {}
    while True:
        X_prev = copy.deepcopy(X_new)
        for state in gridwdeter.states:
            all_actions_lead_to_X = True
            for act in gridwdeter.actions:
                next_state = gridwdeter.transition[state][act]
                if next_state not in X_prev:
                    all_actions_lead_to_X = False
                    break
            if all_actions_lead_to_X:
                X_new.add(state)
                pol[state] = act
        if X_prev == X_new:
            break
    return X_new, pol

def get_attractor(gridW, F):
    Y = set(copy.deepcopy(gridW.states))
    X = set(copy.deepcopy(F))
    Ysets = [Y]
    Xsets = [X]
    
    while True:
        APre_X_Y = get_APre(gridW, X, Y)
        X.update(APre_X_Y)
        
        if Xsets[-1] == X:
            break
        
        Y.difference_update(X)
        Ysets.append(copy.deepcopy(Y))
        Xsets.append(copy.deepcopy(X))
    
    pol = {state: set() for state in Y}
    for state in Y:
        for act in gridW.actions:
            next_states = gridW.transition[state][act]
            if any([next_state in X for next_state in next_states.keys()]) and all([next_state in Y for next_state in next_states.keys()]):
                pol[state].add(act)
                
    return Ysets, Xsets, pol

def printPolicy(gridw, pol, polfile):
    with open(polfile, 'w') as f:
        for s, actions in pol.items():
            f.write(str(s) + ": " + ", ".join(actions) + '\n')
