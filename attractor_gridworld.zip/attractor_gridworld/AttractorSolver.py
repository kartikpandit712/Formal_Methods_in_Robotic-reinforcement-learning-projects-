from Gridworld import *
import copy

def get_attr_deter(gridw, F):
    """
    :param gridw: a gridworld instance for deterministic transition system
    :param F: a set of final states.
    :return: the fixed point for the positive attractor.
    """
    Xset = []  # a list of X0, X1, X2 ... constructed from the attractor
    pol = dict([])  # a policy that ensures F is reached with positive probability from the given state in the positive attractors.
    X = copy.deepcopy(F)
    while True:
        for state in gridw.states:
            for act in gridw.actions:
                # Implement the condition to indicate if the state can be added into X_i+1 given X_i
                # If the state can reach F with positive probability from its current policy
                if state not in F and (state not in pol or pol[state] != act):
                     continue
                next_state = tuple(np.array(state) + np.array(act))
                if gridw.checkinside(next_state):
                    X.add(next_state)
                    if pol.get(state) is None:
                        pol[state] = set()
                    pol[state].add(act)

                print("State: ", state, "Action: ", act)
                print("Next: ", next_state)
                print("X: ", X)

                print("Policy: ", pol)
                print("#####################")
        # Implement the condition when this computation shall terminate.
        if X == Xset[-1] if Xset else False:
            break
        Xset.append(copy.deepcopy(X))

    return Xset, pol


def get_attr_uc(gridw, F):
    """
    :param gridw: a gridworld instance for deterministic transition system
    :param F: a set of unsafe states to avoid.
    :return: the fixed point for the positive attractor.
    """
    Xset = []  # a list of X0, X1, X2 ... constructed from the attractor
    pol = dict([])  # a policy that ensures F is avoided
    X = copy.deepcopy(F)
    while True:
        for state in gridw.states:
            for act in gridw.actions:
                # Implement the condition to indicate if the state can be added into X_i+1 given X_i
                if state in F:
                    continue
                next_state = tuple(np.array(state) + np.array(act))
                if gridw.checkinside(next_state) and next_state not in F:
                    X.add(state)
                    if pol.get(state) is None:
                        pol[state] = set()
                    pol[state].add(act)

        # Implement condition when this computation shall terminate.
        if X == Xset[-1] if Xset else False:
            break
        Xset.append(copy.deepcopy(X))

    return Xset, pol


def get_pos_attr(gridw, F):
    """
    :param gridw: a gridworld instance for stochastic transition dynamics
    :param F: a set of final states.
    :return: the fixed point for the positive attractor.
    """
    Xset = []  # a list of X0, X1, X2 ... constructed from the attractor
    pol = dict([])  # a policy that ensures F is reached with positive probability from the given state in the positive attractors.
    X = copy.deepcopy(F)
    while True:
        for state in gridw.states:
            for act in gridw.actions:
                # Implement the condition to indicate if the state can be added into X_i+1 given X_i
                if state in F:
                    continue
                next_states = gridw.get_next_supp(state, act)
                if next_states.intersection(X):
                    X.add(state)
                    pol[state] = act
    
        # Implement condition when this computation shall terminate.
        if X == Xset[-1] if Xset else False:
            break
        Xset.append(copy.deepcopy(X))

    return Xset, pol


def get_APre(gridW, X, Y):
    """
    :param gridW: an MDP.
    :param X: a set of states.
    :param Y: another set of states to stay within.
    :return: APre(X,Y)
    """
    Apre = set()
    for x in X:
        for act in gridW.actions:
            next_states = gridW.get_next_supp(x, act)
            if next_states.issubset(Y):
                Apre.add(x)
                break
    return Apre


def get_attractor(gridW, F):
    """
    :param gridW: an MDP.
    :param F: a set of target states
    :return: the almost-sure winning region to reach F, and an almost-sure winning strategy that maps each state to a set of actions enabled from that state.
    """
    Y = copy.deepcopy(gridW.states)
    Ysets = []
    Xnew = set([])
    X = copy.deepcopy(F)
    Xsets = []
    flag = True
    while True:
        if X == Xnew:
            break
        Xnew = copy.deepcopy(X)
        Apre = get_APre(gridW, X, Y)
        X = X.union(Apre.intersection(F))

    # Construct the policy
    pol = dict()
    for state in Y:
        pol[state] = set()
        for action in gridW.actions:
            next_states = gridW.get_next_supp(state, action)
            if next_states.issubset(X):
                pol[state].add(action)

    return Ysets, Xsets, pol


def printPolicy(gridw, pol, polfile):
    f = open(polfile, 'w')
    for s in pol.keys():
        f.write(str(s) + str(": ") + str(pol[s]) + '\n')
    f.close()
    return