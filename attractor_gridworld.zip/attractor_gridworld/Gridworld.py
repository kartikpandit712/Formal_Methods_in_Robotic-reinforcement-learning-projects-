# -*- coding: utf-8 -*-
"""
Created on Thu Jun 29 16:27:12 2023

@author: hma2
"""

import numpy as np
import copy


class GridWorld:
    def __init__(self, height, width, init, Wall, Sink, stoPar, labels=None):
        """
        Fully observable gridworld for labeled Markov decision process.
        :param height: number of rows
        :param width: number of cols.
        :param init: (x,y) coordinate for the initial state
        :param Wall: a set of cells that cannot be traversed.
        :param Sink: a set of cells that lead to a "Sink" state.
        :param stoPar: a parameter within [0,1] to define the stochasticity in the agent dynamics.
        If the agent moves North, with a probability 1-2*stoPar, it moves to the intended cell.
        with probability stoPar, it moves to one of the neighboring cells. If the next cell is a wall cell, it stays in the same cell.
        :param labels: a dictionary that labels for each state, a set of atomic propositions evaluated true.
        """
        self.init = init
        self.Sink = Sink
        self.Wall = Wall
        # Change your stochasticity here
        self.stoPar = stoPar
        self.states = self.getStates(height, width)
        self.removeWall(Wall)  # Walls cannot be entered, so remove walls from valid states
        self.actions = self.getActions()
        self.transition = self.getTransition()
        self.ChangeSinkTrans()
        self.labels = labels

    def getLabel(self, state):
        # return the label of a given state.
        return self.labels(state)

    def getStates(self, height, width):
        # Get all possible states
        states = []
        for i in range(height):
            for j in range(width):
                states.append((i, j))
        return states

    def getActions(self):
        # 5 actions including stay and 4 different directions.
        actions = [(0, 1), (0, -1), (-1, 0), (1, 0), (0, 0)]  # right, left down, up, stay
        return actions

    def complementaryActions(self, action):
        # Use to find out stochastic transitions, if stay, no stochasticity, if other actions, return possible stochasticity directions.
        if action == (0, 0):
            return []
        elif action[0] == 0:
            return [(1, 0), (-1, 0)]
        else:
            return [(0, 1), (0, -1)]

    def getTransition(self):
        # Constructing transition function trans[state][action][next_state] = probability
        stoPar = self.stoPar
        trans = {}
        for st in self.states:
            trans[st] = {}
            for act in self.actions:
                if act == (0, 0):
                    trans[st][act] = {}
                    trans[st][act][st] = 1
                else:
                    trans[st][act] = {}
                    trans[st][act][st] = 0
                    tempst = tuple(np.array(st) + np.array(act))
                    if self.checkinside(tempst):
                        trans[st][act][tempst] = 1 - 2 * stoPar
                    else:
                        trans[st][act][st] += 1 - 2 * stoPar
                    for act_ in self.complementaryActions(act):
                        tempst_ = tuple(np.array(st) + np.array(act_))
                        if self.checkinside(tempst_):
                            trans[st][act][tempst_] = stoPar
                        else:
                            trans[st][act][st] += stoPar
        self.check_trans(trans)
        return trans

    def check_trans(self, trans):
        # Check if the transitions are constructed correctly
        for st in trans.keys():
            for act in trans[st].keys():
                if abs(sum(trans[st][act].values()) - 1) > 0.01:
                    print("st is:", st, " act is:", act, " sum is:", sum(self.stotrans[st][act].values()))
                    return False
        print("Transition is correct")
        return True

    def checkinside(self, st):
        # If the state is valid or not
        if st in self.states:
            return True
        return False

    def removeWall(self, Wall):
        # Walls cannot be entered, so remove walls from valid states
        for st in Wall:
            self.states.remove(st)

    def ChangeSinkTrans(self):
        # Sink should all go to "Sink" states
        for s in self.Sink:
            self.transition[s] = {}
            for act in self.actions:
                self.transition[s][act] = {}
                self.transition[s][act]["Sink"] = 1.0

    def get_reward(self, Reward):
        # Assign a reward function to the MDP. Not required for qualitative planning.
        return

    def get_next_supp(self, s, a):
        """

        :param s: state
        :param a: action
        :return: a set of possible next states that can be reached with probability >0.
        """
        X = set([])
        for next_state, prob in self.transition[s][a].items():
            if prob > 0:
                X.add(next_state)
        return X

    def generate_traj(self, pi, T):
        # Generate a trajectory of length T given a policy pi and the initial state.
        traj = []
        state = self.init
        for _ in range(T):
            if state == 'Sink':
                break  # Stop if the state is 'Sink'
            action = pi[state]
            next_states = list(self.transition[state][action].keys())
            probabilities = list(self.transition[state][action].values())
            next_state = np.random.choice(next_states, p=probabilities)
            traj.append((state, action, next_state))
            state = next_state
        return traj


def get_deterTS(height, width, Wall, Sink, init):
    stoPar = 0
    GridWDeter = GridWorld(height, width, init, Wall, Sink, stoPar)
    return GridWDeter


def get_MDP(height, width, Wall, Sink, init):
    stoPar = 0.2
    GridW = GridWorld(height, width, init, Wall, Sink, stoPar)
    return GridW


def main():
    height = 10  # GridWorld height
    width = 10  # GridWorld width
    Wall = [(3, 7), (3, 8), (4, 7), (6, 7), (7, 6), (7, 7), (8, 6)]  # Bouncing walls in the Map
    Sink = [(0, 0), (7, 0)]  # Consider it as Cheese & Trap position
    init = (0, 0)  # Initial state
    GridWorld = get_deterTS(height, width, Wall, Sink, init)

    # Define a simple policy that always moves to the right
    pi = {}
    for state in GridWorld.states:
        pi[state] = (0, 1)  # Move right for all states

    T = 10  # Length of the trajectory
    trajectory = GridWorld.generate_traj(pi, T)

    # Print the generated trajectory
    for step, (state, action, next_state) in enumerate(trajectory):
        print(f"Step {step + 1}: State {state}, Action {action}, Next State {next_state}")

if __name__ == "__main__":
    GridWorld = main()
    print("Done the construction of a gridworld")