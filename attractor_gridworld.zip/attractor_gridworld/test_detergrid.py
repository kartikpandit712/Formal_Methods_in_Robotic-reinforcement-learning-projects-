from Gridworld import *
from AttractorSolver import *

# Define the GridWorld parameters
height = 10  # GridWorld height
width = 10  # GridWorld width
Wall = [(3, 7), (3, 8), (4, 7), (6, 7), (7, 6), (7, 7), (8, 6)]   # Bouncing walls in the Map
Sink = [(0, 0), (7, 0)]   # Consider it as Cheese & Trap positions

#Wall = [(2, 2)]
#Sink = [(3, 3)]

init = (0, 0)  # Initial state
gridwdeter = get_deterTS(height, width, Wall, Sink, init)

# Choose your own target set (F) and unsafe set
F = {(5, 5), (8, 8), (4, 6)}  # Example target set
unsafe = {(2, 2), (2, 3), (2, 4)}  # Example unsafe set
# F = {(3, 2)}
# unsafe = {(3, 2)}
# Calculate the positive attractor for F
Xset1, pol1 = get_attr_deter(gridwdeter, F)

# Calculate the positive attractor for F while avoiding unsafe states
Xset2, pol2 = get_attr_uc(gridwdeter, unsafe)

# Print the results
print("Positive Attractor for F:", Xset1[-1])
print("Policy for Positive Attractor for F:", pol1)
print("Positive Attractor for F (avoiding unsafe states):", Xset2[-1])
print("Policy for Positive Attractor for F (avoiding unsafe states):", pol2)

# Print the policies to text files
policy_file1 = "policy_attractor.txt"
policy_file2 = "policy_attractor_avoiding_unsafe.txt"

printPolicy(gridwdeter, pol1, policy_file1)
printPolicy(gridwdeter, pol2, policy_file2)

# Print confirmation messages
print(f"Policy for Positive Attractor for F saved to {policy_file1}")
print(f"Policy for Positive Attractor for F (avoiding unsafe states) saved to {policy_file2}")